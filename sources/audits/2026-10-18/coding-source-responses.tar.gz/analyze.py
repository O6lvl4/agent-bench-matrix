import json,pathlib,sys,copy,shutil,hashlib,datetime,subprocess,re,collections,os
sys.dont_write_bytecode=True
import refresh_coding_sources as c
ROOT=pathlib.Path('/workspace/shared/ai-coding-oct18/base'); OUT=pathlib.Path(os.environ.get('ABM_CODING_OUT','/workspace/shared/ai-coding-oct18')); OUT.mkdir(parents=True,exist_ok=True); SHADOW=OUT/'shadow'; CACHE=pathlib.Path(os.environ.get('ABM_CODING_CACHE',str(OUT/'responses'))); DATE='2026-10-18'
def load(p):return json.loads(p.read_text())
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
T=[load(p) for p in sorted((ROOT/'data/tables').glob('*.json')) if load(p)['category'] in ('coding','terminal')]
IX=load(pathlib.Path(os.environ.get('ABM_CODING_INDEX',str(OUT/'fetch-index.json')))); BASE='0310eeef75423a981e4d8bd158721c95a6b372a3'
FILES=sorted(set(['data/models.json']+['data/tables/'+t['id']+'.json' for t in T]+[str(p.relative_to(ROOT)) for t in T for p in (ROOT/t['snapshot']).parent.iterdir() if p.is_file()]))
BEFORE={p:sha((ROOT/p).read_bytes()) for p in FILES}
for p in FILES:
 dest=SHADOW/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,dest)
c.ROOT=SHADOW
class Refresh(c.Refresh):
 def __init__(self,*args):
  super().__init__(*args)
  for t in T:
   if t['id'].startswith('deepswe-'):
    primary=t['fetched'][0]
    self.sources[t['id']].sort(key=lambda e:0 if e['url']==primary else 2 if e.get('purpose')=='frontend_pricing' else 1)
 def project(self,t,old):
  if t['category']=='terminal':
   raw=json.loads(self.text(t['id']));new={k:raw[k] for k in old};return new,new==old
  return super().project(t,old)
 def changed_rows(self,t,new):
  if t['category']=='terminal':raise ValueError('Terminal source projection changed; complete native diff requires manual extractor review. Prior table preserved.')
  return super().changed_rows(t,new)
W=Refresh(CACHE,DATE,T,[x for x in IX if x['group']=='coding'])
AUD=[];NATIVE=[];DELTA=[];CAND=[]
for original in T:
 tid=original['id'];t=copy.deepcopy(original);oldtext=(ROOT/t['snapshot']).read_text()
 try:old=json.loads(oldtext)
 except json.JSONDecodeError:old=oldtext
 a={'table':tid,'id':tid,'category':t['category'],'checked':DATE,'rows_before':len(t['rows']),'rows_after':len(t['rows']),'retrieved_before':t['retrieved'],'retrieved_after':t['retrieved'],'snapshot':t['snapshot'],'sources':W.sources[tid]}
 try:
  assert all(e.get('status')==200 for e in W.sources[tid]),'One or more primary/supporting source fetches failed'
  new,same=W.project(t,old)
  if not same:dump(OUT/'source-deltas'/f'{tid}.json',{'before':old,'after':new})
  if t['category']=='coding':prov=W.run_one(t)
  elif not same:t['rows']=W.changed_rows(t,new)
  native={}
  if tid.startswith('terminal-'):
   count=0
   assert len(new['rows'])==len(t['rows'])
   for row in t['rows']:
    native_row=next(s for s in new['rows'] if row['row_url'].endswith('/'+s['id']))
    assert row['rank']==native_row['rank'];assert row['score']==native_row['metrics']['accuracy'];count+=1
    mapping={'trials':'n_trials','cost_usd':'total_cost_usd','ci95_half_width':'accuracy_ci95_half_width','successes':'passes' if tid=='terminal-bench-science-0-1' else 'successes','stderr':'accuracy_stderr','reward_hacks_pct':'reward_hacks'}
    for key,value in row['score_extra'].items():
     if not isinstance(value,(int,float)) or isinstance(value,bool):continue
     if key=='trials':nv=native_row['metrics'].get('n_trials',native_row['n_trials'])
     else:nv=native_row['metrics'][mapping.get(key,key)]
     assert value==nv,(tid,row['system'],key,value,nv);count+=1
   native={'row_count':len(t['rows']),'rank_and_primary_metric':'passed','all_normalized_numeric_score_extras':'passed','numeric_values_checked':count}
  elif tid.startswith('deepswe-'):
   native={'row_count':len(t['rows']),'all_native_scores_frontend_costs_configuration_and_pricing_snippet':'passed','supporting_snippet_byte_preserved':(SHADOW/t['snapshot']).parent.joinpath('frontend-pricing.js').read_bytes()==(ROOT/t['snapshot']).parent.joinpath('frontend-pricing.js').read_bytes()}
  elif tid.startswith('swe-bench-live-'):native={'row_count':len(t['rows']),'resolved_over_total_score_check':'passed'}
  elif tid in {'swe-bench-full','swe-bench-lite','swe-bench-verified','swe-bench-bash-only','swe-bench-multilingual','swe-bench-multimodal'}:native={'row_count':len(t['rows']),'source_resolved_values':'passed'}
  for row in t['rows']:
   assert all(mid in W.registry for mid in row['model_ids']);assert not row['date'] or re.fullmatch(r'\d{4}-\d{2}(?:-\d{2})?',row['date']) and row['date']<=DATE
  assert t['newest_row_date']==max((r['date'] for r in t['rows'] if r['date']),default=None)
  changed=original['rows']!=t['rows']
  a.update(status='changed' if changed else 'unchanged',source_data_changed=not same,rows_changed=changed,rows_after=len(t['rows']),complete_projection_comparison='different' if not same else 'equal')
  if native:NATIVE.append({'table':tid,**native})
  if changed:
   a['retrieved_after']=DATE;t['retrieved']=DATE
   for p in ['data/tables/'+tid+'.json',t['snapshot'],'sources/'+tid+'/provenance.json']:
    target=OUT/'proposed'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SHADOW/p,target)
   CAND.append(tid)
   # Exact row operations. Identity stable model/system/config/date; duplicates indexed.
   def key(row):return json.dumps([row.get(k) for k in ('system','agent','model_raw','model_config','date')],sort_keys=True)
   arows=collections.defaultdict(list);brows=collections.defaultdict(list)
   for r in original['rows']:arows[key(r)].append(r)
   for r in t['rows']:brows[key(r)].append(r)
   changes=[]
   for k in sorted(set(arows)|set(brows)):
    aa=arows[k];bb=brows[k]
    for n in range(max(len(aa),len(bb))):
     before=aa[n] if n<len(aa) else None;after=bb[n] if n<len(bb) else None
     if before!=after:changes.append({'operation':'add' if before is None else 'remove' if after is None else 'update','identity':json.loads(k),'before':before,'after':after})
   DELTA.append({'table':tid,'changes':changes})
 except Exception as e:a.update(status='failed-preserved',error=type(e).__name__+': '+str(e),rows_changed=False)
 a['table_sha256']=sha((ROOT/('data/tables/'+tid+'.json')).read_bytes());a['snapshot_sha256']=sha((ROOT/t['snapshot']).read_bytes());AUD.append(a)
 print(tid,a['status'],a.get('error',''),flush=True)
AFTER={p:sha((ROOT/p).read_bytes()) for p in FILES}
assert BEFORE==AFTER,'Original repository bytes changed during read-only audit'
coverage={'tables':len(T),'coding':sum(t['category']=='coding' for t in T),'terminal':sum(t['category']=='terminal' for t in T),'changed':sum(a['status']=='changed' for a in AUD),'unchanged':sum(a['status']=='unchanged' for a in AUD),'failed':sum(a['status']=='failed-preserved' for a in AUD),'http_requests':len([x for x in IX if x['group']=='coding']),'http_ok':sum(x.get('status')==200 for x in IX if x['group']=='coding'),'rows_before':sum(len(t['rows']) for t in T),'rows_after':sum(a['rows_after'] for a in AUD)}
dump(OUT/'coding.json',{'date':DATE,'timezone':'Asia/Tokyo','base_commit':BASE,'categories':['coding','terminal'],'method':'Fresh grouped official HTTP reads. Complete native JSON/YAML/CSV/HTML/RSC leaderboard projections compared mechanically with saved snapshots; unchanged tables retain every original byte and date. DeepSWE prices parsed without executing downloaded code. Separate SWE-bench Pro public/private variants retained. Original repository read-only; supported changes proposed separately.','coverage':coverage,'changed_tables':CAND,'tables':AUD})
dump(OUT/'coding-row-deltas.json',DELTA);dump(OUT/'coding-model-additions.json',W.proposals)
dump(OUT/'coding-files.json',[{'path':p,'before_sha256':h,'after_sha256':AFTER[p],'byte_preserved':h==AFTER[p]} for p,h in BEFORE.items()])
dump(OUT/'coding-verification.json',{'date':DATE,'base_commit':BASE,'tables_checked':len(T),'complete_projection_comparisons_passed':sum(a.get('complete_projection_comparison')=='equal' for a in AUD),'registry_identity_checks':'passed','row_date_checks':'passed','newest_row_date_checks':'passed','original_files_byte_preserved':len(FILES),'model_registry_edited_by_this_worker':False,'model_registry_proposals':len(W.proposals),'native_checks':NATIVE,'full_build':'Parent task owns final aggregate build and validation'})
print(json.dumps(coverage),flush=True)

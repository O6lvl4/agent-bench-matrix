import urllib.request,urllib.error,json,datetime,hashlib,pathlib,time
R=pathlib.Path('.');I=json.load(open('fetch-index.json'));(R/'fetch-index-initial.json').write_text(json.dumps(I,indent=2)+'\n')
for n,e in enumerate(I):
 if e.get('status')==200:continue
 old=e.copy();r={k:v for k,v in e.items() if k not in ('error','status','final_url','bytes','sha256','requested_at')};r['attempt']='unchanged-request retry after transient proxy failure';r['requested_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();d=e['request_description'];u=d;body=None
 if ' (POST ' in d:u,b=d.split(' (POST ',1);body=b.removesuffix(')').encode()
 try:
  if u=='https://labs.scale.com/leaderboard/swe_bench_pro_private':
   a=json.load(open('single-retry.json'));r.update(a);b=(R/'responses'/('retry-'+e['file'])).read_bytes();r['file']=e['file']
  else:
   try:resp=urllib.request.urlopen(urllib.request.Request(u,data=body,headers={'User-Agent':'Mozilla/5.0','Content-Type':'application/json'}),timeout=90)
   except urllib.error.HTTPError as ex:resp=ex
   with resp:b=resp.read();r.update(status=resp.status,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),final_url=resp.url)
  (R/'responses'/e['file']).write_bytes(b)
 except Exception as ex:r['error']=type(ex).__name__+': '+str(ex)
 r['attempts']=[old,{k:v for k,v in r.items() if k!='attempts'}];I[n]=r
 (R/'fetch-index.json').write_text(json.dumps(I,indent=2)+'\n');print(json.dumps({k:v for k,v in r.items() if k in ('url','status','error','bytes')}),flush=True)
 time.sleep(0.4)

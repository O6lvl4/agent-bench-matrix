import json,pathlib,difflib,hashlib,tarfile,datetime,collections
R=pathlib.Path('/workspace/shared/ai-coding-oct18');B=R/'base';P=R/'proposed';IX=json.loads((R/'fetch-index.json').read_text());A=json.loads((R/'coding.json').read_text());V=json.loads((R/'coding-verification.json').read_text())
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
A['coverage']['logical_source_requests']=len(IX);A['coverage']['http_attempts']=sum(len(e.get('attempts',[e])) for e in IX);A['coverage']['initial_http_ok']=sum(e.get('status')==200 for e in json.loads((R/'fetch-index-initial.json').read_text()));A['coverage']['retry_http_ok']=sum(len(e.get('attempts',[]))>1 and e.get('status')==200 for e in IX)
A['baseline_materialization']='Only coding/terminal tables, model registry and their source directories, read using git show at exact base_commit; prior working-tree contents excluded.'
A['scope']='Every existing category=coding or category=terminal table at base_commit. No gaps or unrelated table families included.'
A['completed_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
for t in A['tables']:
 t['byte_preserved_in_baseline']=True
 t['data_path']='data/tables/'+t['id']+'.json'
 if t['status']!='failed-preserved':t['checks']={'complete_primary_source_projection':'equal' if t['complete_projection_comparison']=='equal' else 'supported-delta-extracted','all_model_ids_exist_in_original_registry':'passed','row_date_and_newest_row_date':'passed'}
 else:t['checks']={'fresh_complete_projection':'not completed; original table and dates preserved'}
dump(R/'coding.json',A)
V['fresh_tables_successfully_checked']=sum(t['status']!='failed-preserved' for t in A['tables']);V['failed_preserved_tables']=[t['id'] for t in A['tables'] if t['status']=='failed-preserved'];V['registry_identity_checks']='passed for all successfully checked tables';V['row_date_checks']='passed for all successfully checked tables';V['newest_row_date_checks']='passed for all successfully checked tables'
manifest=[];patch=[]
for p in sorted(P.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(P);before=(B/rel).read_text() if (B/rel).exists() else ''
 patch+=difflib.unified_diff(before.splitlines(keepends=True),p.read_text().splitlines(keepends=True),fromfile='a/'+str(rel) if (B/rel).exists() else '/dev/null',tofile='b/'+str(rel))
 manifest.append({'path':str(rel),'before_sha256':sha(B/rel) if (B/rel).exists() else None,'after_sha256':sha(p)})
(R/'coding.patch').write_text(''.join(patch));dump(R/'proposed-manifest.json',manifest)
# Confirm every new Live row against the fresh native JSONL record, retaining set/total/date/verified/URL.
source=next(e for e in IX if e['url']=='https://swe-bench-live.github.io/reports-0605.jsonl');native=[json.loads(s) for s in (R/'responses'/source['file']).read_text().splitlines() if s.strip()];checks=[]
for tid in A['changed_tables']:
 t=json.loads((P/'data/tables'/f'{tid}.json').read_text());old=json.loads((B/'data/tables'/f'{tid}.json').read_text());oldkeys={(r['system'],r['date']) for r in old['rows']}
 for row in t['rows']:
  if (row['system'],row['date']) in oldkeys:continue
  source_row=next(s for s in native if s['set']==tid.removeprefix('swe-bench-live-') and s['name']==row['system'] and s['date']==row['date']);cnt=source_row['resolved'];cnt=len(cnt) if isinstance(cnt,list) else cnt
  assert row['score']==round(cnt/source_row['total']*100,1) and row['score_extra']['resolved_count']==cnt and row['score_extra']['num_valid_inst']==source_row['total'];assert row['verified']==source_row.get('verified') and row['row_url']==source_row.get('url')
  checks.append({'table':tid,'source_set':source_row['set'],'source_name':source_row['name'],'resolved_count':cnt,'total':source_row['total'],'score':row['score'],'date':row['date'],'verified':row['verified'],'row_url':row['row_url'],'all_normalized_new_row_fields_match_source':'passed'})
V['changed_row_native_checks']=checks;V['proposed_files']=manifest;dump(R/'coding-verification.json',V)
with tarfile.open(R/'coding-source-responses.tar.gz','w:gz') as f:
 for p in sorted((R/'responses').iterdir()):
  if p.name.startswith('retry-'):continue
  f.add(p,arcname='responses/'+p.name)
 for name in ('fetch-index.json','fetch-index-initial.json','single-retry.json','collect.py','retry.py','analyze.py','finalize.py','refresh_coding_sources.py'):f.add(R/name,arcname=name)
print(json.dumps(A['coverage']));print('Proposed files:',len(manifest));print('Archive bytes:',(R/'coding-source-responses.tar.gz').stat().st_size)

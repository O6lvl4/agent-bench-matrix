import json,pathlib,urllib.request,urllib.error,concurrent.futures,hashlib,datetime,sys
from lxml import html
ROOT=pathlib.Path('/workspace/shared/ai-coding-oct18/base'); OUT=pathlib.Path('/workspace/shared/ai-coding-oct18'); CACHE=OUT/'responses'; CACHE.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
import refresh_coding_sources as c
T=[json.loads(p.read_text()) for p in sorted((ROOT/'data/tables').glob('*.json')) if json.loads(p.read_text())['category'] in ('coding','terminal')]
jobs={u:{'description':u,'tables':ids,'group':'coding'} for u,ids in c.source_jobs(T).items()}
def one(x):
 d=x['description'];u=d;body=None
 if ' (POST ' in d:u,b=d.split(' (POST ',1);body=b.removesuffix(')').encode()
 out={'request_description':d,'url':u,'tables':list(dict.fromkeys(x['tables'])),'group':x['group'],'file':sha(d.encode())[:16],'retrieved':'2026-10-18','requested_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 if 'purpose' in x:out['purpose']=x['purpose']
 try:
  req=urllib.request.Request(u,data=body,headers={'User-Agent':'Mozilla/5.0','Content-Type':'application/json'})
  try:r=urllib.request.urlopen(req,timeout=90)
  except urllib.error.HTTPError as e:r=e
  with r:
   b=r.read();out.update(status=r.status,final_url=r.url,bytes=len(b),sha256=sha(b))
  (CACHE/out['file']).write_bytes(b)
 except Exception as e:out['error']=type(e).__name__+': '+str(e)
 print(json.dumps({k:out[k] for k in ['url','status','error','bytes'] if k in out}),flush=True)
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as p:index=list(p.map(one,jobs.values()))
home=next((x for x in index if x['url']=='https://deepswe.datacurve.ai/' and x.get('status')==200),None)
if home:
 try:
  modules=html.fromstring((CACHE/home['file']).read_bytes()).xpath('//link[@rel="modulepreload"]/@href'); assert modules
  index.append(one({'description':urllib.parse.urljoin(home['final_url'],modules[0]),'tables':home['tables'],'group':'coding','purpose':'frontend_pricing'}))
 except Exception as e:index.append({'url':'https://deepswe.datacurve.ai/','tables':home['tables'],'purpose':'frontend_pricing','error':str(e)})
dump(OUT/'fetch-index.json',index)
